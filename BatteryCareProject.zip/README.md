# Battery Care (Android 10+)
Starter project. Build from GitHub Actions: push to `main` or manually run the workflow `Build Battery Care APK`; download the artifact.

Included: battery percentage and charging-current estimate (mA), theme selector, battery warning preferences, device-admin screen-lock prompt, basic low-battery monitor.
Limitations: charging current is device-reported and may be unavailable/inaccurate; tap-lock in this prototype only works on the app screen, not globally. The restart button is currently informational. Android background timing is not guaranteed; foreground monitoring requires notification permission and is subject to OS rules. Rescue mode is a preference/notification concept, not automatic system Battery Saver activation.
