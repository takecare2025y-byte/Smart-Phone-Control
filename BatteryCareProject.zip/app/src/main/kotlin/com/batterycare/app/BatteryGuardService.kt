package com.batterycare.app
import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.*
import android.os.*
import android.widget.Toast

class BatteryGuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
            val level = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val prefs = getSharedPreferences("bc", MODE_PRIVATE)
            if (level >= 10) prefs.edit().putBoolean("lockedAtLow", false).apply()
            if (level <= 5 && prefs.getBoolean("lowAlert", true)) {
                val adm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
                if (adm.isAdminActive(ComponentName(this@BatteryGuardService, LockAdminReceiver::class.java))) {
                    val pm = getSystemService(POWER_SERVICE) as PowerManager
                    if (pm.isInteractive && !prefs.getBoolean("lockedAtLow", false)) {
                        adm.lockNow()
                        prefs.edit().putBoolean("lockedAtLow", true).apply()
                    }
                    postNotice("Battery is critically low ($level%).")
                } else postNotice("Battery is critically low ($level%). Enable Screen Lock permission in the app.")
            }
            handler.postDelayed(this, 40_000)
        }
    }
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel("batterycare", "Battery Care Protection", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        startForeground(101, Notification.Builder(this, "batterycare").setContentTitle("Battery Care active").setContentText("Monitoring battery protection").setSmallIcon(android.R.drawable.ic_lock_idle_charging).build())
        handler.post(tick)
    }
    private fun postNotice(msg:String) {
        val n = Notification.Builder(this, "batterycare").setContentTitle("Battery Care").setContentText(msg).setSmallIcon(android.R.drawable.ic_lock_idle_charging).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(102, n)
    }
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
