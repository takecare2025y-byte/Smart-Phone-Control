package com.batterycare.app
import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.*
import android.os.*
import android.view.*
import android.widget.*
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var batteryText: TextView
    private lateinit var chargeText: TextView
    private lateinit var root: LinearLayout
    private var lastTap = 0L
    private val admin = ComponentName(this, LockAdminReceiver::class.java)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("bc", MODE_PRIVATE)
        buildUI()
        updateBattery()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 3)
    }
    private fun buildUI() {
        val dark = prefs.getBoolean("dark", false)
        val bg = if(dark) 0xFF101010.toInt() else 0xFFF7F8FA.toInt()
        val fg = if(dark) 0xFFFFFFFF.toInt() else 0xFF171717.toInt()
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,20); setBackgroundColor(bg) }
        setContentView(root)
        val top=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        top.addView(label("🔋  Battery Care", 24, fg, true), LinearLayout.LayoutParams(0,-2,1f))
        top.addView(button("⚙", fg) { settings() })
        root.addView(top)
        batteryText=label("85%",48,0xFF16A34A.toInt(),true).apply { gravity=Gravity.CENTER }
        chargeText=label("Current Battery",16,fg,false).apply { gravity=Gravity.CENTER }
        root.addView(batteryText); root.addView(chargeText)
        addCard("5% Battery Alert","Low battery protection",prefs.getBoolean("lowAlert",true)) { prefs.edit().putBoolean("lowAlert",it).apply() }
        addCard("10% Rescue Mode","Charging reminder",prefs.getBoolean("rescue",true)) { prefs.edit().putBoolean("rescue",it).apply() }
        root.addView(button("⏻   Restart Options",fg) { Toast.makeText(this,"Use Accessibility permission to open the system power menu (not included in this first build).",Toast.LENGTH_LONG).show() })
        root.addView(label("Tap to Lock",18,fg,true))
        val method = RadioGroup(this).apply { orientation=RadioGroup.HORIZONTAL }
        val single=RadioButton(this).apply { text="Single Tap"; setTextColor(fg); id=1 }
        val double=RadioButton(this).apply { text="Double Tap"; setTextColor(fg); id=2 }
        method.addView(single); method.addView(double); method.check(if(prefs.getBoolean("doubleTap",false)) 2 else 1)
        method.setOnCheckedChangeListener { _, id -> prefs.edit().putBoolean("doubleTap", id==2).apply() }
        root.addView(method)
        root.addView(label("Tap the battery area to lock this screen. (Global tap lock needs special accessibility/overlay support.)",12,fg,false))
        root.setOnTouchListener { _, event ->
            if(event.action==MotionEvent.ACTION_UP && event.y < 300) {
                val now=System.currentTimeMillis()
                if(!prefs.getBoolean("doubleTap",false) || now-lastTap < 450) lockScreen()
                lastTap=now
            }; false
        }
        root.addView(label("Battery Care • v1.0",12,0xFF777777.toInt(),false).apply { gravity=Gravity.CENTER })
    }
    private fun addCard(title:String, subtitle:String, enabled:Boolean, onChange:(Boolean)->Unit) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(12,10,8,10) }
        val text=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        text.addView(label(title,17,0xFF16803D.toInt(),true)); text.addView(label(subtitle,13,0xFF777777.toInt(),false))
        row.addView(text,LinearLayout.LayoutParams(0,-2,1f))
        val sw=Switch(this).apply { isChecked=enabled; setOnCheckedChangeListener { _, checked -> onChange(checked) } }
        row.addView(sw); root.addView(row)
    }
    private fun settings() {
        val dark=prefs.getBoolean("dark",false)
        val choices= arrayOf("Dark (Black)","Light (White)")
        AlertDialog.Builder(this).setTitle("Settings • Theme").setSingleChoiceItems(choices,if(dark)0 else 1){ dialog,which ->
            prefs.edit().putBoolean("dark",which==0).apply(); dialog.dismiss(); recreate()
        }.setNeutralButton("About"){ _,_-> AlertDialog.Builder(this).setTitle("About Battery Care").setMessage("Battery Care\nVersion 1.0").setPositiveButton("OK",null).show() }.setNegativeButton("Close",null).show()
    }
    private fun lockScreen() {
        val dpm=getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if(!dpm.isAdminActive(admin)) {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,admin).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"Permission lets Battery Care lock your screen."))
        } else dpm.lockNow()
    }
    private fun updateBattery() {
        val bm=getSystemService(BATTERY_SERVICE) as BatteryManager
        val level=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        batteryText.text="$level%"
        val current=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val status=registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged=status?.getIntExtra(BatteryManager.EXTRA_PLUGGED,0) ?: 0
        chargeText.text=if(plugged!=0) "⚡ Charging  •  ${abs(current)/1000} mA" else "Current Battery"
        batteryText.postDelayed({updateBattery()},2000)
    }
    private fun label(s:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold)setTypeface(null,1); setPadding(0,10,0,10) }
    private fun button(s:String,color:Int,click:()->Unit)=Button(this).apply { text=s; setTextColor(color); setOnClickListener{click()} }
    override fun onStart() { super.onStart(); if(prefs.getBoolean("lowAlert",true)) try { startForegroundService(Intent(this,BatteryGuardService::class.java)) } catch(_:Exception){} }
}
