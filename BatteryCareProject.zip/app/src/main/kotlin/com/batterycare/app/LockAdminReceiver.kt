package com.batterycare.app
import android.app.admin.DeviceAdminReceiver
class LockAdminReceiver : DeviceAdminReceiver()
