# Smart Phone Control

Android starter project (Kotlin). Minimum Android API 23 (Android 6.0); designed to run on Android 10 and newer too.

## Included in this first build
- Battery monitoring foreground service.
- At 5% or below, attempts to lock the screen every 40 seconds.
- Auto-lock checks stop at 10% or above.
- Skips a lock attempt when an active call is detected (grant Phone permission).
- Shows a persistent notification; charging below 10% is labelled Rescue Mode.
- Shortcut to Android Battery Saver settings.
- Device Admin permission flow for screen locking.
- GitHub Actions workflow builds a debug APK.

## Important Android limitations
- Grant Device Admin manually inside the app for screen locking.
- Grant Phone permission if you want call-state detection.
- Android/OEM battery management can delay or stop background work; exact 40-second timing is not guaranteed.
- This app cannot force system-wide restrictions on camera, flashlight, games, video apps, or reboot/power-on the phone.
- Rescue Mode is currently a notification + Battery Saver settings shortcut, not a system-wide mode.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Or push to GitHub. Open Actions > Build Android APK > run workflow (or push to `main`). Download the `SmartPhoneControl-debug-apk` artifact.
