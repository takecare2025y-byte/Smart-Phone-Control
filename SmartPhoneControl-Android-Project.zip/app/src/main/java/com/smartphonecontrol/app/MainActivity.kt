package com.smartphonecontrol.app

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val adminRequest = 100
    private val phonePermissionRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Smart Phone Control\n\nBattery Protection"
            textSize = 25f
        }
        val info = TextView(this).apply {
            text = "\n• 5%: Auto Lock Protection starts\n• Every 40 seconds: lock check\n• 10%: protection stops\n• Charging below 10%: Rescue Mode notification\n\nCalls and SMS are not blocked. Keep the app's ongoing notification enabled. Android may delay background work on some phones."
            textSize = 16f
        }
        val adminButton = Button(this).apply {
            text = "Enable Device Admin (required for auto-lock)"
            setOnClickListener { requestAdmin() }
        }
        val startButton = Button(this).apply {
            text = "Start Battery Protection"
            setOnClickListener { startProtection() }
        }
        val batteryButton = Button(this).apply {
            text = "Open Battery Saver Settings"
            setOnClickListener {
                try { startActivity(Intent(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "Battery Saver settings not available", Toast.LENGTH_SHORT).show() }
            }
        }
        layout.addView(title); layout.addView(info); layout.addView(adminButton)
        layout.addView(startButton); layout.addView(batteryButton)
        setContentView(layout)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), phonePermissionRequest)
        }
    }

    private fun requestAdmin() {
        val component = ComponentName(this, LockAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allows Smart Phone Control to lock the screen when battery is critically low.")
        }
        startActivityForResult(intent, adminRequest)
    }

    private fun startProtection() {
        val service = Intent(this, BatteryGuardService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
        Toast.makeText(this, "Battery protection started", Toast.LENGTH_LONG).show()
    }
}
