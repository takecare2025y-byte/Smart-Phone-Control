package com.smartphonecontrol.app

import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat

class BatteryGuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastLockAt = 0L
    private var receiverRegistered = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_BATTERY_CHANGED) {
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
                val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                updateNotification(pct, plugged)
                if (pct >= 10) lastLockAt = 0L
            }
        }
    }

    private val lockRunnable = object : Runnable {
        override fun run() {
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
            if (pct <= 5) {
                val inCall = if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                    tm.callState != TelephonyManager.CALL_STATE_IDLE
                } else false
                val admin = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val component = ComponentName(this@BatteryGuardService, LockAdminReceiver::class.java)
                if (!inCall && admin.isAdminActive(component)) {
                    admin.lockNow()
                    lastLockAt = SystemClock.elapsedRealtime()
                }
            }
            handler.postDelayed(this, 40_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, buildNotification("Monitoring battery level…"))
        if (!receiverRegistered) {
            registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            receiverRegistered = true
        }
        handler.post(lockRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun updateNotification(pct: Int, plugged: Boolean) {
        val message = when {
            pct < 0 -> "Battery monitoring is active"
            pct <= 5 -> "Critical battery: $pct%. Auto Lock Protection active (40-second check)."
            plugged && pct < 10 -> "Rescue Mode: charging below 10%. Calls and SMS remain available."
            pct >= 10 -> "Battery $pct%. Auto Lock Protection is off."
            else -> "Battery $pct%. Low-battery protection is monitoring."
        }
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(7, buildNotification(message))
    }

    private fun buildNotification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "battery_guard")
            .setSmallIcon(android.R.drawable.ic_lock_idle_low)
            .setContentTitle("Smart Phone Control")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(open).setOngoing(true).build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("battery_guard", "Battery protection", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(lockRunnable)
        if (receiverRegistered) unregisterReceiver(batteryReceiver)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
